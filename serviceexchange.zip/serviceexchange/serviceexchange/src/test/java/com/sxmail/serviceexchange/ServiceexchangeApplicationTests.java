package com.sxmail.serviceexchange;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceexchangeApplicationTests {

	@Test
	void contextLoads() {
	}

}
