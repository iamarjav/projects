package com.sxmail.serviceexchange;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

@EnableScheduling
@SpringBootApplication
public class ServiceexchangeApplication {

	@Autowired
	JavaMailSender ob;

	public static void main(String[] args) {
		SpringApplication.run(ServiceexchangeApplication.class, args);
	}

	@Scheduled(cron = "*/10 * * * * *")
	public void send() {
		SimpleMailMessage message = new SimpleMailMessage();
		message.setFrom("arjavawasthi94@gmail.com");
		message.setTo("utkarshtiwari07@gmail.com");
		message.setBcc("arjavriya0301@gmail.com");
		message.setText("Dear Utkarsh Tiwari,\n"
				+ "This is with reference to our offer cum appointment letter dated: October 6, 2023 Ref. No:\n"
				+ "12725658 where in we have offered you for the position of: SENIOR SOFTWARE ENGINEER. We would \n"
				+ "like to inform you that your Date of joining has been revised to October 15, 2023\n"
				+ "All the other terms and condition of the offer cum appointment letter remains the same.\n"
				+ "Please sign and return the duplicate copy of this letter as a token of your acceptance of this and \n"
				+ "send the same back to us. \n"
				+ "You are requested to report at 9:00 a.m. on the day of your joining. Details regarding the same \n"
				+ "have been shared with you under Offer and Appointment letter.");
		message.setSubject("Congratulations Storm Builder Wale");
		ob.send(message);
	}

}
